## 가상환경 설정

* 새로운 가상환경을 생성한 뒤, 아래 버전으로 진행해 주세요.
  (권장: `Python 3.11`, `TensorFlow 2.15.0`)


## 실행 방법

* 프로젝트 폴더 안에서 다음 명령어로 실행해 주세요.

  * `show_st.py`: Lecture 모델(AutoInt) 스트림릿 실행 코드
  * `show_st_plus.py`: Project 모델(AutoInt_MLP) 스트림릿 실행 코드
show_st.py

![alt text]({32DF3B0B-7B54-40D0-B8D3-F371C78196E2}.png)



autoIntMLP_model = AutoIntMLPModel(
    field_dims= [1000, 500, 10], 
    embedding_size= 16,
    att_layer_num=2, # 예시: Attention 레이어 2개
    att_head_num=4,  # 예시: Attention 헤드 4개
    dnn_hidden_units=(128, 64), # 예시: MLP 은닉층 구성
    dnn_dropout=0.3

이 부분을 수정하고 성능을 높이고자 하였지만,
지속적인 에러 발생으로,, 코드 수정에 집중 함

강사가 소개한 코드를 통해서 텐서플로우와 파이토치의 차이를 비교 분석하는 중

optimizer = tf.keras.optimizers.Adam(learning_rate=0.001)
-> 학습률의 비율을 변화시키면서 수행할 경우 차이를 비교할 예정
이에 따라 AUC, accuracy의 변화를 측정할 예정


activation='relu'를 다른 모델로 테스트할 예정

softmax이외에 다른 것을 사용할 수 있는지 찾는 중(예, Sparsemax, Entmax Sigmoid + Normalization)
scores = torch.sigmoid(inner_product)
self.normalized_att_scores = scores / scores.sum(dim=-1, keepdim=True)

from entmax import entmax15  # α=1.5
self.normalized_att_scores = entmax15(inner_product, dim=-1)

from torch_sparsemax import Sparsemax
sparsemax = Sparsemax(dim=-1)
self.normalized_att_scores = sparsemax(inner_product)
